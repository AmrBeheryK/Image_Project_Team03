import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import math

def normalize_angle(angle):
    return (angle + math.pi) % (2 * math.pi) - math.pi

class StanleyNode(Node):
    def __init__(self):
        super().__init__('stanley_node')
        self.sub_state = self.create_subscription(
            Float32MultiArray, '/state', self.state_callback, 10)
        self.sub_cmd = self.create_subscription(
            Float32MultiArray, '/motor_command', self.cmd_callback, 10)
        self.pub = self.create_publisher(Float32MultiArray, '/steering_cmd', 10)

        self.Y_ref = 0.0
        self.pwm_motor = 0
        self.previous_delta = 0.0  # radians

        self.max_steer_rad=math.radians(50.0)
        self.stop_distance = 3.6
        self.alpha = 1
        self.k = 0.8
        self.epsilon = 0.05

    def cmd_callback(self, msg):
        self.Y_ref = msg.data[0]
        self.pwm_motor = int(msg.data[1])
       # self.pwm_motor=0

    def state_callback(self, msg):
        x   = msg.data[0]
        y   = msg.data[1]
       # y=0
        yaw = msg.data[2]
        v   = msg.data[3]

        # ✅ Correct rear-wheel velocity to front-wheel velocity
        #v_front = v / max(math.cos(self.previous_delta), 0.1)
        v_safe = v + self.epsilon

        # Cross-track error and heading error
        e_y =-1* (self.Y_ref - y)
        theta_e = normalize_angle(yaw)  # ✅ wrapped, desired heading = 0

        # Stanley control law
        delta_raw = theta_e + math.atan2(self.k * e_y, v_safe)
        delta_raw = normalize_angle(delta_raw)  # ✅ keep delta in valid range
        delta_raw = max(-self.max_steer_rad, min(self.max_steer_rad, delta_raw))
        delta = (1 - self.alpha) * self.previous_delta + self.alpha * delta_raw
        

        # Stop condition
        if x >= self.stop_distance:
            delta = 0.0
            self.pwm_motor = 0

        self.previous_delta = delta

        # Convert to servo angle
        delta_deg = math.degrees(delta)
        delta_deg = max(-50.0, min(50.0, delta_deg))
        servo_angle = delta_deg + 90.0

        msg_out = Float32MultiArray()
        msg_out.data = [servo_angle, float(self.pwm_motor)]
        self.pub.publish(msg_out)

def main(args=None):
    rclpy.init(args=args)
    node = StanleyNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
