import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Float32MultiArray
import numpy as np
import time

def normalize_angle(angle):
    return (angle + np.pi) % (2 * np.pi) - np.pi


class LocalizationNode(Node):
    def __init__(self):
        super().__init__('localization_node')

        # Publisher
        self.pub = self.create_publisher(Float32MultiArray, '/state', 10)

        # Subscriber (Fake Arduino)
        self.sub = self.create_subscription(
            String,
            '/arduino_data',
            self.callback,
            10
        )

        self.last_time = None
        # EKF state: [x, y, theta]
        self.x = np.array([[0.0], [0.0], [0.0]])

        # Covariance matrix
        self.P = np.eye(3) * 0.1

        self.get_logger().info("Localization node started (Fake Arduino mode)")

    def callback(self, arduino_msg):  # ✅ renamed to avoid collision with Float32MultiArray msg
        line = arduino_msg.data

       # self.get_logger().info(f"Raw Arduino string: '{line}'")  # ✅

        if not line.startswith("DATA:"):
            return

        try:
            data = line.replace("DATA:", "")
            parts = data.split(',')
            # ✅ Expect: yaw_measure, v (and optionally yaw_rate)
            yaw_measure = np.deg2rad(float(parts[0]))  # ✅ convert to radians
            v = float(parts[1])
            # If your Arduino sends yaw_rate (omega), parse it here:
            # omega = float(parts[2])
        except Exception as e:
            self.get_logger().warn(f"Failed to parse Arduino data: {e}")
            return

        now = time.time()
        if self.last_time is None:
            self.last_time = now
            return
        dt = now - self.last_time
        dt = max(0.02, min(0.1, dt))  # clamp to sane range
        self.last_time = now
        theta = self.x[2, 0]

        # ------------------------------------------
        # EKF PREDICTION (unicycle model, omega=0)
        # If you have omega from IMU, replace 0 with it
        # ------------------------------------------
        omega = 0.0  # ✅ placeholder; replace with parsed value if available

        F = np.array([
            [1, 0, -v * dt * np.sin(theta)],
            [0, 1,  v * dt * np.cos(theta)],
            [0, 0,  1]
        ])

        # State transition
        self.x[0, 0] += v * dt * np.cos(theta)
        self.x[1, 0] += v * dt * np.sin(theta)
        self.x[2, 0] += omega * dt  # ✅ theta prediction (0 if no omega)
        self.x[2, 0] = normalize_angle(self.x[2, 0])

        Q = np.eye(3) * 0.01
        self.P = F @ self.P @ F.T + Q

        # ------------------------------------------
        # EKF UPDATE (yaw measurement only)
        # ------------------------------------------
        H = np.array([[0, 0, 1]])
        R = np.array([[0.01]])
        z = np.array([[yaw_measure]])

        # ✅ Normalize innovation to handle angle wrap-around
        innovation = z - H @ self.x
        innovation[0, 0] = normalize_angle(innovation[0, 0])

        S = H @ self.P @ H.T + R
        K = self.P @ H.T @ np.linalg.inv(S)

        self.x = self.x + K @ innovation
        self.x[2, 0] = normalize_angle(self.x[2, 0])
        self.P = (np.eye(3) - K @ H) @ self.P

       # self.get_logger().info(
   # f"v={v:.3f}  theta={np.degrees(self.x[2,0]):.1f}°  "
   # f"cos(theta)={np.cos(self.x[2,0]):.3f}  "
   # f"x={self.x[0,0]:.3f} "
   # f"y={self.x[1,0]:.3f}")

        # ------------------------------------------
        # Publish state
        # ------------------------------------------
        out_msg = Float32MultiArray()
        out_msg.data = [
            float(self.x[0, 0]),  # x
            float(self.x[1, 0]),  # y
            float(self.x[2, 0]),  # yaw
            float(v)              # velocity
        ]
        self.pub.publish(out_msg)


def main(args=None):
    rclpy.init(args=args)
    node = LocalizationNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
