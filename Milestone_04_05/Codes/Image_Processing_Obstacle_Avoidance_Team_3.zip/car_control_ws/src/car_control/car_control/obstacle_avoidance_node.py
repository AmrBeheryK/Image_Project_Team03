# obstacle_avoidance_node.py

import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool, Float32MultiArray


class ObstacleAvoidanceNode(Node):

    def __init__(self):
        super().__init__('obstacle_avoidance_node')

        self.sub = self.create_subscription(
            Bool,
            '/obstacle_close',
            self.obstacle_callback,
            10
        )

        self.pub = self.create_publisher(
            Float32MultiArray,
            '/motor_command',
            10
        )

        # Lane settings
        self.lane_positions = [0.0, 1.0]
        self.current_lane = 0
        self.Y_ref = self.lane_positions[self.current_lane]

        # Noise filtering
        self.buffer_size = 8
        self.buffer = [False] * self.buffer_size

        self.filtered_obstacle = False
        self.prev_filtered = False

    def obstacle_callback(self, msg):

        # Update buffer
        self.buffer.pop(0)
        self.buffer.append(msg.data)

        # Majority voting filter
        true_count = sum(self.buffer)
        self.filtered_obstacle = true_count > (self.buffer_size // 2)

        # ✅ Rising edge on FILTERED signal
        if self.filtered_obstacle and not self.prev_filtered:
            self.current_lane = 1 - self.current_lane
            self.Y_ref = self.lane_positions[self.current_lane]

        # Speed control
        pwm_motor = 200 if self.filtered_obstacle else 255

        self.prev_filtered = self.filtered_obstacle

        # Publish command
        cmd = Float32MultiArray()
        cmd.data = [self.Y_ref, float(pwm_motor)]
        self.pub.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = ObstacleAvoidanceNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
