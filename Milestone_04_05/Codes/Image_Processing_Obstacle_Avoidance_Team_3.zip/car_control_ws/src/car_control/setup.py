from setuptools import setup

package_name = 'car_control'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='user',
    maintainer_email='user@email.com',
    description='Car control system',
    license='TODO',
    entry_points={
        'console_scripts': [
            'camera_node = car_control.camera_node:main',
            'localization_node = car_control.localization_node:main',
            'obstacle_avoidance_node = car_control.obstacle_avoidance_node:main',
            'stanley_node = car_control.stanley_node:main',
            'arduino_interface_node = car_control.arduino_interface_node:main',
        ],
    },
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/car_launch.py']),
    ],
)
