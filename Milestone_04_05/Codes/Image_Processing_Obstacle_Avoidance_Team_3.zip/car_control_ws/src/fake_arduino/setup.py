from setuptools import setup
import os
from glob import glob

package_name = 'fake_arduino'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='pi',
    maintainer_email='pi@todo.todo',
    description='Fake Arduino simulator',
    license='MIT',
    entry_points={
        'console_scripts': [
            'fake_arduino_node = fake_arduino.fake_arduino_node:main',
            'visualization_node = fake_arduino.visualization_node:main',
        ],
    },
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/fake_arduino']),
        ('share/fake_arduino', ['package.xml']),
        (os.path.join('share', 'fake_arduino', 'launch'),
            glob('launch/*.py')),
    ],
)
