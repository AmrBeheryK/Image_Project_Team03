# visualization_node.py
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import threading
import math
import socket
from dash import Dash, dcc, html
from dash.dependencies import Output, Input
import plotly.graph_objs as go

class VisualizationNode(Node):
    def __init__(self):
        super().__init__('visualization_node')
        self.sub = self.create_subscription(
            Float32MultiArray, '/state', self.state_callback, 10)
        self.x = []
        self.y = []
        self.yaw = 0.0
        self.lock = threading.Lock()

    def state_callback(self, msg):
        with self.lock:
            self.x.append(msg.data[0])
            self.y.append(msg.data[1])
            self.yaw = msg.data[2]
            if len(self.x) > 500:
                self.x.pop(0)
                self.y.pop(0)

def main(args=None):
    rclpy.init(args=args)
    node = VisualizationNode()

    # ROS in background thread
    spin_thread = threading.Thread(target=rclpy.spin, args=(node,), daemon=True)
    spin_thread.start()

    # Dash app on main thread
    app = Dash(__name__)
    app.layout = html.Div([
        dcc.Graph(id='trajectory'),
        dcc.Interval(id='interval', interval=200, n_intervals=0)
    ])

    @app.callback(Output('trajectory', 'figure'), Input('interval', 'n_intervals'))
    def update_graph(_):
        with node.lock:
            x = list(node.x)
            y = list(node.y)
            yaw = node.yaw

        traces = [go.Scatter(x=x, y=y, mode='lines', name='Trajectory', line=dict(color='blue'))]

        if x:
            dx = 0.3 * math.cos(yaw)
            dy = 0.3 * math.sin(yaw)
            traces.append(go.Scatter(
                x=[x[-1], x[-1] + dx],
                y=[y[-1], y[-1] + dy],
                mode='lines+markers',
                marker=dict(symbol='arrow', size=15, color='red',
                            angleref='previous'),
                name='Heading'
            ))

        return {
            'data': traces,
            'layout': go.Layout(
                title='Vehicle Trajectory',
                xaxis_title='X', yaxis_title='Y',
                yaxis=dict(scaleanchor='x'),
                showlegend=True
            )
        }

    # Log the dashboard URL
    ip = socket.gethostbyname(socket.gethostname())
    node.get_logger().info(f"Dashboard available at http://{ip}:8050")

    app.run(host='0.0.0.0', port=8050, debug=False)


if __name__ == '__main__':
    main()
