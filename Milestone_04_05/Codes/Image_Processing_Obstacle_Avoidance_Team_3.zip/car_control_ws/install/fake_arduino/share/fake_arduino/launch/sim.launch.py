from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():

    return LaunchDescription([

        Node(
            package='fake_arduino',
            executable='fake_arduino_node',
            name='fake_arduino',
            output='screen'
        ),

        Node(
            package='fake_arduino',
            executable='visualization_node',
            name='visualization',
            output='screen'
        ),

    ])
