from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(package='car_control', executable='camera_node'),
        Node(package='car_control', executable='localization_node'),
        Node(package='car_control', executable='obstacle_avoidance_node'),
        Node(package='car_control', executable='stanley_node'),
       Node(package='car_control', executable='arduino_interface_node'),
    ])
