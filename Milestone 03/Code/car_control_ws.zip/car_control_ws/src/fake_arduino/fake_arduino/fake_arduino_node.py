import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import math

class FakeArduino(Node):
    def __init__(self):
        super().__init__('fake_arduino')

        self.pub = self.create_publisher(String, '/arduino_data', 10)

        self.t = 0.0
        self.yaw = 0.0

        self.timer = self.create_timer(0.05, self.update)  # 20 Hz

    def update(self):
        # simulate constant forward motion
        v = 0.5

        # simulate yaw dynamics (small oscillation)
        self.yaw += 0.01 * math.sin(self.t)*0

        msg = String()
        msg.data = f"DATA:{self.yaw},{v}"
        self.pub.publish(msg)

        self.t += 0.05


def main(args=None):
    rclpy.init(args=args)
    node = FakeArduino()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
