from setuptools import setup

package_name = 'fake_arduino'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='pi',
    maintainer_email='pi@todo.todo',
    description='Fake Arduino simulator',
    license='MIT',
    entry_points={
        'console_scripts': [
            'fake_arduino_node = fake_arduino.fake_arduino_node:main',
        ],
    },
)
