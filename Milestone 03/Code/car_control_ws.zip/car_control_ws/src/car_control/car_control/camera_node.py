# camera_node.py

import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool
import cv2
import numpy as np
import subprocess


class CameraNode(Node):
    def __init__(self):
        super().__init__('camera_node')

        # Publisher
        self.pub = self.create_publisher(Bool, 'obstacle_close', 10)

        # Timer (10 Hz)
        self.timer = self.create_timer(0.1, self.timer_callback)

        # Start camera stream
        cmd = [
            'rpicam-vid',
            '-t', '0',
            '--inline',
            '--width', '640',
            '--height', '480',
            '--framerate', '10',
            '--codec', 'mjpeg',
            '-o', '-'
        ]

        self.pipe = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        self.data_buffer = b''

        # QR detector
        self.qr_decoder = cv2.QRCodeDetector()

        # CLAHE for lighting robustness
        self.clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))

        # Calibration (UPDATE THESE!)
        self.KNOWN_WIDTH_CM = 3.3
        self.FOCAL_LENGTH = 1263.12

        # Distance threshold (🚨 key parameter)
        self.THRESHOLD_DISTANCE_CM = 40.0


    def get_frame(self):
        """Extract one frame from MJPEG stream"""
        while True:
            self.data_buffer += self.pipe.stdout.read(2048)

            a = self.data_buffer.find(b'\xff\xd8')
            b = self.data_buffer.find(b'\xff\xd9')

            if a != -1 and b != -1:
                jpg = self.data_buffer[a:b+2]
                self.data_buffer = self.data_buffer[b+2:]

                frame = cv2.imdecode(
                    np.frombuffer(jpg, dtype=np.uint8),
                    cv2.IMREAD_COLOR
                )

                return frame

    def timer_callback(self):

        frame = self.get_frame()
        if frame is None:
            return

        # ================================
        # 🧠 IMAGE PROCESSING
        # ================================
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        enhanced = self.clahe.apply(gray)

        # ================================
        # 🔍 QR DETECTION
        # ================================
        data, bbox, _ = self.qr_decoder.detectAndDecode(enhanced)

        msg = Bool()
        msg.data = False  # default

        if bbox is not None and len(bbox) > 0:
            bbox = np.int32(bbox)

            pixel_width = np.linalg.norm(bbox[0][0] - bbox[0][1])

            if pixel_width > 0:
                # Distance calculation
                distance = (self.KNOWN_WIDTH_CM * self.FOCAL_LENGTH) / pixel_width

                # 🚨 FLAG LOGIC
                if distance < self.THRESHOLD_DISTANCE_CM:
                    msg.data = True

                # Debug log (optional)
                #self.get_logger().info(f"Distance: {distance:.2f} cm")

        # Publish result
        self.pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = CameraNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
