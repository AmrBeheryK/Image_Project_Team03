# stanley_node.py

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import math
import serial


class StanleyNode(Node):
    def __init__(self):
        super().__init__('stanley_node')

        self.sub_state = self.create_subscription(
            Float32MultiArray, 'state', self.state_callback, 10)

        self.sub_cmd = self.create_subscription(
            Float32MultiArray, 'motor_command', self.cmd_callback, 10)

        self.ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)

        self.Y_ref = 0.0
        self.pwm_motor = 200
        self.previous_delta = 0

        self.stop_dstance = 2
        self.alpha = 0.3
        self.k = 1.0

        self.get_logger().info("Stanley node started")

    def cmd_callback(self, msg):
        self.Y_ref = msg.data[0]
        self.pwm_motor = int(msg.data[1])

    def state_callback(self, msg):
        x = msg.data[0]
        y = msg.data[1]
        yaw = msg.data[2]
        v = msg.data[3]

        e_y = self.Y_ref - y
        theta_e = -yaw

        v_safe = max(v, 0.005)

        # Low-pass filter
        previous_delta_filtered = (1 - self.alpha) * self.previous_delta

        delta = self.alpha * (theta_e + math.atan2(self.k * e_y, v_safe)) + previous_delta_filtered

        # Stop at end of path
        if x >= self.stop_dstance:
            delta = 0
            self.pwm_motor = 0

        self.previous_delta = delta

        delta_deg = math.degrees(delta)
        delta_deg = max(-70, min(70, delta_deg))

        servo_angle = delta_deg + 90

        command = f"{servo_angle},{self.pwm_motor}\n"
        self.ser.write(command.encode())

    # ✅ SAFETY STOP FUNCTION
    def stop_vehicle(self):
        try:
            self.get_logger().info("Stopping vehicle (Ctrl+C)...")
            stop_command = "90,0\n"
            self.ser.write(stop_command.encode())
        except Exception as e:
            self.get_logger().error(f"Stop failed: {e}")

    def destroy_node(self):
        self.stop_vehicle()

        if self.ser.is_open:
            self.ser.close()

        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = StanleyNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Keyboard Interrupt detected!")

    finally:
        node.destroy_node()
        rclpy.shutdown()
