# localization_node.py
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import time
import serial
import numpy as np

class LocalizationNode(Node):
    def __init__(self):
        super().__init__('localization_node')
        self.pub = self.create_publisher(Float32MultiArray, 'state', 10)

        self.ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)

        self.x = np.array([[0.0], [0.0], [0.0]])
        self.P = np.eye(3) * 0.1

        self.last_time=0
        self.timer = self.create_timer(0.05, self.timer_callback)

    def timer_callback(self):
        line = self.ser.readline().decode('utf-8').strip()

        # ✅ Only accept valid data lines
        if not line.startswith("DATA:"):
            return

        try:
            data = line.replace("DATA:", "")
            yaw_measure, v = map(float, data.split(','))
            yaw_measure=yaw_measure*(np.pi/180)
        except:
            return

        current_time = time.time()

        if not hasattr(self, 'last_time'):
            self.last_time = current_time
            return

        dt = current_time - self.last_time
        self.last_time = current_time
        theta = self.x[2,0]

        # EKF Prediction
        F = np.array([[1,0,-v*dt*np.sin(theta)],
                      [0,1, v*dt*np.cos(theta)],
                      [0,0,1]])

        B = np.array([[dt*np.cos(theta)],
                      [dt*np.sin(theta)],
                      [0]])

        self.x = self.x + B*v
        Q = np.eye(3)*0.01
        self.P = F @ self.P @ F.T + Q

        # EKF Update
        H = np.array([[0,0,1]])
        R = np.array([[0.01]])

        y = np.array([[yaw_measure]]) - H @ self.x
        S = H @ self.P @ H.T + R
        K = self.P @ H.T @ np.linalg.inv(S)

        self.x = self.x + K @ y
        self.P = (np.eye(3) - K @ H) @ self.P

        self.x[2,0] = normalize_angle(self.x[2,0])
        msg = Float32MultiArray()
        msg.data = [
        float(self.x[0, 0]),  # x
        float(self.x[1, 0]),  # y
        float(self.x[2, 0]),  # yaw
        float(v)              # velocity
        ]
        self.pub.publish(msg)

def normalize_angle(angle):
    return (angle + np.pi) % (2*np.pi) - np.pi

def main(args=None):
    rclpy.init(args=args)
    node = LocalizationNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
